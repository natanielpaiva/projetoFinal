import { Component } from '@angular/core';
@Component({
    selector: 'home',
    templateUrl: 'app/home/templates/home.template.html'

})
export class HomeComponent {
}


