export class Correios{
    _id:number;
    cep:number;
    logadouro:string;
}


