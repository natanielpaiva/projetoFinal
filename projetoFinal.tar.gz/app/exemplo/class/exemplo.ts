export class Exemplo{
    _id:number;
    exemplo:string;
    exemploNumero:number;
}
