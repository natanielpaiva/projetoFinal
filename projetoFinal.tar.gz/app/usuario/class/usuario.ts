export class Usuario{
    _id:number;
    nome:string;
    idade:number;
    perfil:{
        nome:string
    };
    cep:number;
    endereco:string;
    login:string;
    senha:string;
    constructor(){}
}
