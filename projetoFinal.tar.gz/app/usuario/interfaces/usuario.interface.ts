import { Usuario } from '../class/usuario';

export interface UsuarioInterface{
    listar(): Usuario[];
}

