export class Perfil{
    _id:number;
    nome:string;
}
