import { Component } from '@angular/core';
import './rxjs-operators';
@Component({
    selector: 'projeto4',
    templateUrl: 'app/config/template.html'

})
export class AppComponent {
}
